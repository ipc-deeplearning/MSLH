iptsetpref('ImshowBorder','tight')
loadpath = 'D:\file\project\3Dparticle\Particles_of_different_shapes\data\mask\corn';
paths = dir([loadpath,'\*.png']);
order=60;

for numpine=1:100
    nm_record = [];
    for ii=1:3
        nm = randi([1,10]);
        nm_record(1,ii)=nm;
        m = imread([paths(nm).folder,'\',paths(nm).name]);
        eval([['m',num2str(nm)],'=m;']);
        eval(['mc=',['m',num2str(nm)],';']);
        eval([['mask',num2str(nm)],'=remove_centre(mc);']);
        eval(['mf=',['mask',num2str(nm)],';']);
        eval(['[T,',['R',num2str(nm)],',',['F',num2str(nm)],',',['V',num2str(nm)],']=ZERNIKE_feature(uint8(mf), order);']);
    %     m1=imread([paths(1).folder,'/',paths(1).name]);
    end
    
    T=T;
    eval(['R=cat(4,',['R',num2str(nm_record(1,1))],',',['R',num2str(nm_record(1,2))],',',['R',num2str(nm_record(1,3))],');']);
    eval(['F=cat(2,',['F',num2str(nm_record(1,1))],',',['F',num2str(nm_record(1,2))],',',['F',num2str(nm_record(1,3))],');']);
    eval(['V=cat(2,',['V',num2str(nm_record(1,1))],',',['V',num2str(nm_record(1,2))],',',['V',num2str(nm_record(1,3))],');']);
    
    lamda1=randi([1,5]); lamda2=randi([1,5]); lamda3=randi([1,5]);
    lamda=[lamda1,lamda2,lamda3]/(lamda1+lamda2+lamda3);
    
    g = ZERNIKE_rebuild(m, order, T, F, V, R, lamda);
    g=max(g,0.0);
    imwrite(mat2gray(g),['D:\file\project\3Dparticle\Particles_of_different_shapes\data\moment_reconstra\corn\',num2str(numpine),'.png']);
end