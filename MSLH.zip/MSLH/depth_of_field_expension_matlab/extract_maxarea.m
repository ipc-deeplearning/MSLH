function [extract_area] = extract_maxarea(I, centroids, boundingboxs, areas, maxtomin_position, area_size)
%提取出面积最大的几个区域
%   输出：按面积从大到小排列的10个区域
sizeI = size(I,1);
extract_area = zeros(sizeI,sizeI);
boundingboxs = floor(boundingboxs);

sizea = size(areas,1);
area_num=0;

for j=1:sizea
    if areas(j)>=area_size
        area_num = area_num+1;
    end
end

for i=1:area_num
    m=maxtomin_position(i);
    x=boundingboxs(m,1)+1;
    y=boundingboxs(m,2)+1;
    x_legend = boundingboxs(m,3)-1;
    y_legend = boundingboxs(m,4)-1;
    extract_area(y:y+y_legend,x:x+x_legend) = I(y:y+y_legend,x:x+x_legend);
end

end

