function [centroids, boundingboxs, maxtomin_position,areas] = descend_sort_data_fun(particle_region)
    %功能：将regionprops输出的结果按面积从大到小排列
    %输入：regionprops输出的栈（包含面积、中心位置和最小外接矩形边界）
    %输出：面积从大到小排列后，对应区域的中心位置和最小外接矩形边界
    areas=cat(1,particle_region.Area);
    centroids=cat(1,particle_region.Centroid);
    boundingboxs=cat(1,particle_region.BoundingBox);
    [maxtomin_areas, maxtomin_position] = sort(areas, 'descend');
%     [~, maxtomin_position] = ismember(maxtomin_areas,areas);
end

