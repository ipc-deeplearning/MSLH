function [particle_size_x,particle_size_y,X,Y,grayscale,num] = ideal_simulation_particle_coordinate_information(I)
SE=strel('square',3);
Ibw=im2bw(I,1/255);
Ibw=imerode(Ibw,SE);
Ibw=imdilate(Ibw,SE);
img_p=regionprops(Ibw);
num=size(img_p,1);
[xy, particle_size_range, maxtomin_position, areas] = descend_sort_data_fun(img_p);
particle_size_range = floor(particle_size_range);
particle_size_x=zeros(1,num);
particle_size_y=zeros(1,num);
X=zeros(1,num);
Y=zeros(1,num);
grayscale=zeros(1,num);
for j=1:num
    m=maxtomin_position(j);
    particle_size_x(1,j)=particle_size_range(m,3)-1;
    particle_size_y(1,j)=particle_size_range(m,4)-1;
    X(1,j)=floor(xy(m,1));
    Y(1,j)=floor(xy(m,2));
    [xm,ym,Im,rect]=imcrop(I,[particle_size_range(m,1) particle_size_range(m,2) particle_size_range(m,3)-1 particle_size_range(m,4)-1]);
    BW=im2bw(Im,1/255);
    BW=imerode(BW,SE);
    BW=imdilate(BW,SE);
    Q=find(BW==1);
    num_1=length(Q);
    
%     %%均值
%     Im_gray=[];
%     for k=1:num_1
%         if size(Im,1)==1
%             Im_gray(1,k)=double(Im(1,k));
%         elseif size(Im,2)==1
%             Im_gray(1,k)=double(Im(k,1));
%         else
%             Im_gray(1,k)=double(Im(Q(k,1)));
%         end
%     end
%     gray=mean(Im_gray);
%     grayscale(1,j)=uint8(gray);

    %% 中位数
    Im_gray=[];
    for k=1:num_1
        if size(Im,1)==1
            Im_gray(1,k)=double(Im(1,k));
        elseif size(Im,2)==1
            Im_gray(1,k)=double(Im(k,1));
        else
            Im_gray(1,k)=double(Im(Q(k,1)));
        end
    end
    gray=median(Im_gray);   %中位数
    grayscale(1,j)=uint8(gray);
    
end
end

