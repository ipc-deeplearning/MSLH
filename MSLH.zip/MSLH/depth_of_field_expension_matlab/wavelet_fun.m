function [U] = wavelet_fun(I,lamda,z,pixelsize)
pixelnumx=size(I,2);
pixelnumy=size(I,1);
pixelnumin=min(pixelnumx,pixelnumy);
kexi=0.01;
xarray=1:pixelnumx;
yarray=1:pixelnumy;
[xgrid,ygrid]=meshgrid(xarray,yarray);
x=pixelsize*(xgrid-pixelnumx/2-1);
y=pixelsize*(ygrid-pixelnumy/2-1);

sigma1=pixelnumin*pixelsize/2*sqrt(pi/(lamda*z*log(1/kexi)));
sigma2=pi/(2*pixelsize)*sqrt(lamda*z/(pi*log(1/kexi)));
sigma=min(sigma1,sigma2);
Mfiv=sigma^2/(1+sigma^4);
fiv=pi/(lamda*z)*(sin(pi*((x.^2+y.^2)/(lamda*z)))-Mfiv).*exp(-pi*((x.^2+y.^2)/(lamda*z*sigma^2)));
U=fftshift(ifft2(fftshift(fftshift(fft2(fftshift(I))).*fftshift(fft2(fftshift(fiv))))));

end

