for i=0:20
    I=imread(['D:\file\project\3D_pollen_Unet_paper\数据表格整理\yolo表格数据\聚焦结果\',num2str(i),'.png']);
    Iv1=bwmorph(I,'clean');
    particle_region = regionprops(Iv1);
    [cen, bdbox, maxtomin_position,areas] = descend_sort_data_fun(particle_region);
    [extract_area] = extract_maxarea(Iv1,cen,bdbox,areas,maxtomin_position,100);
    I_out=I.*extract_area;
    imwrite(I_out,['D:\file\project\3D_pollen_Unet_paper\数据表格整理\yolo表格数据\面积大于100筛选结果\',num2str(i),'.png'])
end
