tic;
for i=0:20
    I2=imread(['D:\file\project\3D_pollen_Unet_paper\数据表格整理\yolo表格数据\网络预测\1024\',num2str(i),'.png']);
    I=imread(['D:\file\project\3D_pollen_Unet_paper\数据表格整理\yolo表格数据\衍射图\1024\',num2str(i),'.png']);
    [particle_size2_x,particle_size2_y,X2,Y2,grayscale2,num2] = ideal_simulation_particle_coordinate_information(I2);
    num=size(particle_size2_x,2);
%     mkdir(['D:\file\project\pollen\network_predict\predict-11.9-incoherent-255-transfer\focus_result\predict\wavelet\',num2str(i)]);
    
    for j=1:num
        CA=wavelet_fun(I, 470e-9, -(1+0.01*grayscale2(j))*10^(-3), 1.85e-6);
        Iw=CA.*conj(CA);
        if j==1
            I_syn = Iw;
        else
            I_syn = wavelet_synthesis(I_syn,Iw,particle_size2_x(j),particle_size2_y(j),X2(j),Y2(j));
        end
    end
   imwrite(im2bw(mat2gray(I_syn),0.1),['D:\file\project\3D_pollen_Unet_paper\数据表格整理\yolo表格数据\聚焦结果\',num2str(i),'.png'])
end
toc;