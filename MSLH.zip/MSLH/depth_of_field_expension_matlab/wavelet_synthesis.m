function [I_syn] = wavelet_synthesis(I_syn,I,x_legend,y_legend,x,y)
%此函数用于小波变换系数融合
%   I_syn是基本的小波变换图，I是待提取小波系数系数的图
[I_sizex,I_sizey] = size(I);
y_p=max(floor(y-y_legend)+1,1);
x_p=max(floor(x-x_legend)+1,1);
y_l=min(floor(y+y_legend),I_sizex)-max(floor(y-y_legend)+1,1);
x_l=min(floor(x+x_legend),I_sizey)-max(floor(x-x_legend)+1,1);

[C,S] = wavedec2(I_syn,2,'haar');   %二级分解，但只用到1级系数，所以还是小波变换1级系数合成
A = appcoef2(C,S,'haar',1); 
[H,V,D] = detcoef2('all',C,S,1); 

[C1,S1] = wavedec2(I,2,'haar');
A1 = appcoef2(C1,S1,'haar',1); 
[H1,V1,D1] = detcoef2('all',C1,S1,1); 

y_start = x_p/2;
y_end = (x_p+x_l)/2;
x_start = y_p/2;
x_end = (y_p+y_l)/2;
A(x_start : x_end, y_start : y_end) = A1(x_start : x_end, y_start : y_end);
H(x_start : x_end, y_start : y_end) = H1(x_start : x_end, y_start : y_end);
V(x_start : x_end, y_start : y_end) = V1(x_start : x_end, y_start : y_end);
D(x_start : x_end, y_start : y_end) = D1(x_start : x_end, y_start : y_end);

I_syn = idwt2(A,H,V,D,'haar');

end

