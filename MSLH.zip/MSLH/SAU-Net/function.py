import random
import time
import datetime
import sys
from torch.autograd import Variable
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F


device_ids = [0,1]
MAE = torch.nn.L1Loss(size_average=None, reduce=None, reduction='mean')
MSE = torch.nn.MSELoss(size_average=None, reduce=None, reduction='mean')

class l1_loss(nn.Module):
    def __init__(self):
        super(l1_loss, self).__init__()
        return

    def forward(self, p_pred, p_true):
        loss = MAE(p_pred, p_true)
        return loss


class l1_reg_loss(nn.Module):
    def __init__(self):
        super(l1_reg_loss, self).__init__()
        return

    def forward(self, p_pred, p_true):
        loss = MAE(p_pred, p_true) + 0.01 * torch.mean(torch.abs(p_pred))
        return loss


class l2_loss(nn.Module):
    def __init__(self):
        super(l2_loss, self).__init__()
        return

    def forward(self, p_pred, p_true):
        loss = MSE(p_pred, p_true)
        return loss
