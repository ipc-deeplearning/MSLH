import argparse
import sys
import os

import torchvision.transforms as transforms
import numpy as np
from torchvision.utils import save_image
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torch
import time

from model import *
from dataset import DIFFdata

parser = argparse.ArgumentParser()
parser.add_argument('--batchsize', type=int, default=1, help='size of the batches')
parser.add_argument('--dataroot', type=str, default='/media/yrx/disk1/LHX/datasets/data_set_Z_moment_pollen_incoherent_gray-particlenum/', help='root directory of the dataset')
parser.add_argument('--input_nc', type=int, default=1, help='number of channels of input data')
parser.add_argument('--output_nc', type=int, default=1, help='number of channels of output data')
parser.add_argument('--size', type=int, default=256, help='size of the data (squared assumed)')
parser.add_argument('--cuda', action='store_true', help='use GPU computation')
parser.add_argument('--n_cpu', type=int, default=0, help='number of cpu threads to use during batch generation')
parser.add_argument('--Dense_Unet', type=str, default='/media/yrx/disk1/LHX/1.8_batch16_6conv_0grad/incoherent_255_moment_and_realphoto_gray-particlenum/saved_models/hologram_mask/generator_abs_50.pth', help='Dense_Unet checkpoint file')
opt = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = "3"
device_ids = [0]
cuda = True if torch.cuda.is_available() else False

###### Definition of variables ######
# Networks
net_D = Dense_Unet(opt.input_nc, opt.output_nc)

if cuda:
    net_D.cuda(device_ids[0])
    net_D = nn.DataParallel(net_D, device_ids=device_ids)

# Load state dicts
net_D.load_state_dict(torch.load(opt.Dense_Unet))

# Set model's test mode
net_D.eval()

# Inputs & targets memory allocation
Tensor = torch.cuda.FloatTensor if opt.cuda else torch.Tensor
input_A = Tensor(opt.batchsize, opt.input_nc, opt.size, opt.size)
input_B = Tensor(opt.batchsize, opt.output_nc, opt.size, opt.size)

# Dataset loader
transforms_ = [transforms.ToTensor()]
dataloader = DataLoader(DIFFdata(opt.dataroot, transforms_ = transforms_, mode='verify_1024real_21photo_v2'), batch_size=opt.batchsize, shuffle=False, num_workers=opt.n_cpu)

# if not os.path.exists('output/net_abs'):
#     os.makedirs('output/net_abs')

start = time.time()

for i, batch in enumerate(dataloader):
    # Set model input
    real_A = Variable(input_A.copy_(batch['img'])).cuda(device_ids[0]) if opt.cuda else Variable(input_A.copy_(batch['img']))

    # Generate output
    real_fake_A = net_D(real_A).data
    fake_A = real_fake_A

    # Save image files
    name_str = batch['name']
    name_str = str(name_str[0])
    name_str = name_str.split('/')[-1]
    save_image(fake_A, '/media/yrx/disk1/LHX/datasets/data_set_Z_moment_pollen_incoherent_gray-particlenum/predict_1024real_21photo_v2/%s' % name_str)

    sys.stdout.write('\rGenerated images %04d of %04d' % (i+1, len(dataloader)))

sys.stdout.write('\n')

end = time.time()
runTime = end - start
print("运行时间：", runTime, "秒")